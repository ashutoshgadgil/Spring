package org.dem.Spring2;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringContainer {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		
		Book b=(Book) context.getBean("book");

		System.out.println("Book Id :"+b.getBookid());
		System.out.println("Book Name :"+b.getBookname());
		
		Product p=(Product) context.getBean("pro");
		System.out.println(p.getProduct_name());
	}

}
