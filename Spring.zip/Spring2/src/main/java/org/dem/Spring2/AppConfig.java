package org.dem.Spring2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

	@Bean
	public Book book()
	{
		Book b=new Book();
		b.setBookid("501");
		b.setBookname("Java");
		return b;
	}
	
	@Bean
	public Product pro()
	{
		Product p=new Product();
		p.setProduct_name("Laptop");
		return p;
	}
}
