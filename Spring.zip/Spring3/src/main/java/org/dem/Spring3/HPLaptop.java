package org.dem.Spring3;

import org.springframework.stereotype.Service;

@Service("HPLaptop")
public class HPLaptop implements Processor{


	public void setProcessor(String pr) {
		System.out.println("Processor HP : "+pr);
		
	}

}
