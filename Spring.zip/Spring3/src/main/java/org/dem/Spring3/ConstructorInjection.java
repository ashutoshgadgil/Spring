package org.dem.Spring3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class ConstructorInjection {
	private Processor pro;
	
	@Autowired
	ConstructorInjection(@Qualifier("AcerLaptop") Processor pr)  // Constructor injection
	{
		this.pro=pr;
	}
	
	public void showProcessor(String pr)
	{
		pro.setProcessor(pr);
	}
}
