package org.dem.Spring3;

import org.springframework.stereotype.Service;

@Service("AcerLaptop")
public class AcerLaptop implements Processor{

	public void setProcessor(String pr) {
		System.out.println("Processor Acer : "+pr);
		
	}

}
