package org.dem.Spring3;

public interface Processor {
	public void setProcessor(String pr);
}
