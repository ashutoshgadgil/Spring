package org.dem.SpringSetterInjection;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("org.dem.SpringSetterInjection")
public class AppConfig {
	
}
