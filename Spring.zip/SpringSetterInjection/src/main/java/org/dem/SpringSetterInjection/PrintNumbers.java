package org.dem.SpringSetterInjection;

import org.springframework.stereotype.Service;

@Service("PrintNumbers")
public class PrintNumbers {
	
	public void showNum()
	{
		for(int i=1;i<=10;i++)
		System.out.print(i+" ");
	}
}
