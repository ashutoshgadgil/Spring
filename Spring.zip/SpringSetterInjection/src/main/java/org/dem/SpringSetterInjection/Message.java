package org.dem.SpringSetterInjection;

import org.springframework.stereotype.Service;

@Service("Message")
public class Message {

	public String getMessage()
	{
		return "Welcome";
	}
}
