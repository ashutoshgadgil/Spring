package org.dem.Spring1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringContainer {

	public static void main(String[] args) {
		
		// Creating the container object to access the beans from application Context.xml
		// when we have the applicationContext.xml file
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		
		// Initialization of Bean Object
		
		Student s=(Student)context.getBean("stu1");
		System.out.println("Student Name : "+s.getName());
		
		Employee e=(Employee) context.getBean("emp");
		System.out.println("Employee Id :"+e.getId());
		System.out.println("Employee Name :"+e.getName());
		
	}

}
