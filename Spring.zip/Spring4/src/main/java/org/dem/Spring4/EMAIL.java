package org.dem.Spring4;

import org.springframework.stereotype.Service;

@Service("EMAIL")
public class EMAIL implements MessageService{

	public void sendMessage(String message) {
		System.out.println(message+"(Email)");
		
	}

}
