package org.dem.Spring4;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringContainer {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfiguration.class);
		
		SetterInjection s=context.getBean(SetterInjection.class);
	
		s.showMessage("sending message...");		
		
	}

}
