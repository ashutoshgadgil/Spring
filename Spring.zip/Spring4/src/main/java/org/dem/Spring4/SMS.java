package org.dem.Spring4;

import org.springframework.stereotype.Service;

@Service("SMS")
public class SMS implements MessageService{
	
	public void sendMessage(String message) {
		System.out.println(message+"(Text Message)");		
	}

}
