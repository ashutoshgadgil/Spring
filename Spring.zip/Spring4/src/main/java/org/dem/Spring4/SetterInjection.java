package org.dem.Spring4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class SetterInjection {

	private MessageService messageService;
	
	@Autowired
	@Qualifier("EMAIL")
	public void setMessage(MessageService message)
	{
		this.messageService=message;
	}
	
	public void showMessage(String message)
	{
		messageService.sendMessage(message);
	}
}
