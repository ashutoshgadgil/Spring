package org.dem.Spring4;

public interface MessageService {
	public void sendMessage(String message);
}
