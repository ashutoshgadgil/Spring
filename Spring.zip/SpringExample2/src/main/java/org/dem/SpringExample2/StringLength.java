package org.dem.SpringExample2;

import org.springframework.stereotype.Service;

@Service("StringLength")
public class StringLength implements operation{

	public int getResult() {
		String str="abc";
		System.out.print("String Length is : ");
		return str.length();
	}

}
