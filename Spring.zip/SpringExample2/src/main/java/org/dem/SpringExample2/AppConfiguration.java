package org.dem.SpringExample2;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("org.dem.springExample2")
public class AppConfiguration {
	
}
