package org.dem.SpringExample2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class ConstructorInjection {

	public operation opr;
	@Autowired
	ConstructorInjection(@Qualifier("Addition") operation opr)
	{
		this.opr=opr;
	}
	
	public void show()
	{
		System.out.println(opr.getResult());
	}
}
