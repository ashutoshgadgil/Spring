package org.dem.SpringExample2;

import org.springframework.stereotype.Service;

@Service("Addition")
public class Addition implements operation {

	public int getResult() {
		int a=10;
		int b=20;
		System.out.println("Addition is : ");
		return (a+b);
	}

}
