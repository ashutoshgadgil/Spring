package org.dem.SpringExample2;

public interface operation {
	public int getResult();
}
