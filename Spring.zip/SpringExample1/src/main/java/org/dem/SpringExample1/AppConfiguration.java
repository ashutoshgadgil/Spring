package org.dem.SpringExample1;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("org.dem.SpringExample1")
public class AppConfiguration {

}
