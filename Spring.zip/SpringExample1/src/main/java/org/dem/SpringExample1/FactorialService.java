package org.dem.SpringExample1;

import org.springframework.stereotype.Service;

@Service("FactorialService")
public class FactorialService {
	
	public int getFactorial(int n)
	{
		int fact=1;
		System.out.println("Factorial of "+n+" is :");
		
		while(n!=0)
		{
			fact=fact*n;
			n--;
		}
		return fact;
	}
}
