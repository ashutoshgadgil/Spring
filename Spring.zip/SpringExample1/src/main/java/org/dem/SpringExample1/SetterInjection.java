package org.dem.SpringExample1;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class SetterInjection {

	Scanner s=new Scanner(System.in);
	
	public FactorialService fc;
	
	@Autowired
	@Qualifier("FactorialService")
	public void getObject(FactorialService fc)
	{
		this.fc=fc;
	}
	
	public void showFactorial()
	{
		System.out.println("Enter a number : ");
		int n=s.nextInt();
		System.out.println(fc.getFactorial(n));
	}
}
