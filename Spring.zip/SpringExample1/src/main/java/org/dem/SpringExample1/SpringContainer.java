package org.dem.SpringExample1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringContainer {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfiguration.class);
		
		SetterInjection fc=context.getBean(SetterInjection.class);
		
		fc.showFactorial();

	}

}
